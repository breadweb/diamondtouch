using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DTFlash
{
    public partial class MessageForm : Form
    {
        private enum States
        {
            Pre, RampUP, Visible, RampDown, Complete
        }

        private static List<MessageForm> messages = new List<MessageForm>();

        private States state = States.Pre;
        private int rampUpTime = 0;
        private int rampDownTime = 0;
        private int visibleTime = 0;

        private int ticksToRampUp = 200;
        private int ticksToRampDown = 200;
        private int ticksVisible = 500;
        private bool resized = false;

        private MessageForm()
        {
            InitializeComponent();
        }

        public static void Show( string message )
        {
            ShowMessage( message, 3000 );
        }

        public static void Show( string message, string name )
        {
            Show( message );
        }

        public static void ShowMessage( string message, int duration )
        {
            if( duration < 2000 )
                throw new ApplicationException( "No one will even see the message" );

            MessageForm form = new MessageForm();
            form.Initialize( message, duration );
            messages.Add( form );

        }

        private void MessageForm_Paint( object sender, PaintEventArgs e )
        {
            if( !resized )
            {
                SizeF size = e.Graphics.MeasureString( label1.Text, label1.Font );
                this.Size = new Size( (int)(size.Width + 22), (int)(size.Height + 22) );
            }
        }

        private void Initialize( string message, int duration )
        {
            this.Paint += new PaintEventHandler( MessageForm_Paint );

            duration = duration / 10;

            Opacity = 0;
            rampUpTime = 0;
            rampDownTime = 0;
            visibleTime = 0;
            ticksToRampUp = 100;
            ticksToRampDown = 100;
            ticksVisible = duration - ticksToRampDown - ticksToRampUp;
            label1.Text = message;
            state = States.RampUP;
            this.Show();
        }

        private void timer_Tick( object sender, EventArgs args )
        {
            StateMachine();
        }
        private void StateMachine()
        {
            int yPosition = 0;
            for( int i=0; i < messages.Count; i++ )
            {
                MessageForm form = messages[i];
                if( form == this )
                    break;
                yPosition += form.Height;
            }
            int diff = this.Location.Y - yPosition;
            if( diff != 0 )
                this.Location = new Point( this.Location.X, (diff>0 ? Location.Y-1 : yPosition) );

            switch( state )
            {
                case States.Pre:
                    break;
                case States.RampUP:
                    if( rampUpTime >= ticksToRampUp )
                    {
                        state = States.Visible;
                        this.Opacity = 1.0;
                    }
                    else
                    {
                        rampUpTime++;
                        this.Opacity = rampUpTime / (double)ticksToRampUp;
                    }
                    break;

                case States.Visible:
                    this.Opacity = 1.0;
                    if( visibleTime >= ticksVisible )
                        state = States.RampDown;
                    else
                        visibleTime++;
                    break;

                case States.RampDown:
                    if( rampDownTime >= ticksToRampDown )
                    {
                        state = States.Complete;
                        this.Opacity = 0;
                    }
                    else
                    {
                        rampDownTime++;
                        this.Opacity = (ticksToRampDown - rampDownTime) / (double)ticksToRampDown;
                    }
                    break;

                case States.Complete:
                    messages.Remove( this );
                    this.Opacity = 0;
                    this.Close();
                    break;
            }
        }
    }
}