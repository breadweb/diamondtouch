//'
//'
//' Copyright 2008-2009 Circle Twelve Inc.
//' All Rights Reserved.
//' 
//' Permission to use, copy and modify this software and its
//' documentation for educational, research and non-profit
//' purposes, without fee, and without a written agreement is
//' hereby granted, provided that the above copyright notice and
//' the following three paragraphs appear in all copies, and the
//' software and documentation is not redistributed.
//' 
//' To request Permission to incorporate this software into
//' commercial products contact Circle Twelve Inc, 945 Concord Street
//' Framingham, MA 01701.
//' 
//' IN NO EVENT SHALL CIRCLE TWELVE INC BE LIABLE TO ANY PARTY FOR DIRECT,
//' INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
//' INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
//' SOFTWARE AND ITS DOCUMENTATION, EVEN IF CIRCLE TWELVE INC HAS BEEN ADVISED
//' OF THE POSSIBILITY OF SUCH DAMAGES.
//' 
//' CIRCLE TWELVE INC SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
//' NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
//' FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
//' HEREUNDER IS ON AN "AS IS" BASIS, AND CIRCLE TWELVE INC HAS NO OBLIGATIONS
//' TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
//' MODIFICATIONS.
//'
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;

namespace DTFlash {
	/// <summary>
	/// Summary description for DTFlash.
	/// </summary>
	public class DTFlash : System.Windows.Forms.Form {
		private System.ComponentModel.IContainer components;
		private string m_FlashFilename   = "grayball.swf";
		private bool m_Maximized   = false;
		private bool m_FullScreen   = false;
		private bool m_ShowStatusBar = false;
		private bool m_EnableSegments   = false;
		private bool m_EnableSignals   = false;														  
		private int m_FlashMovieWidth = 0; 																														
		private int m_FlashMovieHeight =0; 																																			   
		private string m_Title   = "";
		private System.Windows.Forms.Timer tmrStopAndExit;
		private bool m_FlashMovieLoaded = false;
		private bool m_IgnoreSubsequentIdenticalEvents = false;
		private bool m_PromptForUserRotations = false;
		private bool m_ShowResizingDirectionArrows = true;
		private bool m_ShowMovementDirectionArrows = true;
		private bool m_ShowTouchDataInTitleBar = false;
		private string[] m_lastTouchEventString;
		private string toucherRotationsStr = "";
		private System.Windows.Forms.Label lblElapsedTime;
        private int[] m_rotateUser = new int[] { 0, 0, 0, 0, 0 };
		private String flashSwfPath;
		public Size m_topologyMapSize = new Size(1600, 1600);
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.Button btnHideBrowseButton;
		private System.Windows.Forms.StatusBar statusBar1;
		private bool diamondTouchStarted;
        private Dictionary<string, string> settings = new Dictionary<string, string>();
        private AxDIAMONDTOUCHLib.AxDiamondTouch axDiamondTouch1;
        private AxShockwaveFlashObjects.AxShockwaveFlash axShockwaveFlash1;
        private string logFile = @"C:\DTFlash.log";

        public bool m_UseAS2SetVariable = false;
        public bool m_UseAS3CallFunction = true;

		public DTFlash() {
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DTFlash));
            this.tmrStopAndExit = new System.Windows.Forms.Timer(this.components);
            this.lblElapsedTime = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnHideBrowseButton = new System.Windows.Forms.Button();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.axDiamondTouch1 = new AxDIAMONDTOUCHLib.AxDiamondTouch();
            this.axShockwaveFlash1 = new AxShockwaveFlashObjects.AxShockwaveFlash();
            ((System.ComponentModel.ISupportInitialize)(this.axDiamondTouch1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axShockwaveFlash1)).BeginInit();
            this.SuspendLayout();
            // 
            // tmrStopAndExit
            // 
            this.tmrStopAndExit.Tick += new System.EventHandler(this.tmrStopAndExit_Tick);
            // 
            // lblElapsedTime
            // 
            this.lblElapsedTime.BackColor = System.Drawing.Color.LightGray;
            this.lblElapsedTime.Location = new System.Drawing.Point(86, 258);
            this.lblElapsedTime.Name = "lblElapsedTime";
            this.lblElapsedTime.Size = new System.Drawing.Size(346, 84);
            this.lblElapsedTime.TabIndex = 51;
            this.lblElapsedTime.Text = "0 ms";
            this.lblElapsedTime.Visible = false;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(10, 9);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(144, 27);
            this.btnBrowse.TabIndex = 54;
            this.btnBrowse.Text = "Browse for .swf...";
            this.btnBrowse.Visible = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnHideBrowseButton
            // 
            this.btnHideBrowseButton.Location = new System.Drawing.Point(173, 9);
            this.btnHideBrowseButton.Name = "btnHideBrowseButton";
            this.btnHideBrowseButton.Size = new System.Drawing.Size(153, 27);
            this.btnHideBrowseButton.TabIndex = 55;
            this.btnHideBrowseButton.Text = "Hide Browse Button";
            this.btnHideBrowseButton.Visible = false;
            this.btnHideBrowseButton.Click += new System.EventHandler(this.btnHideBrowseButton_Click);
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 334);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(503, 27);
            this.statusBar1.TabIndex = 56;
            // 
            // axDiamondTouch1
            // 
            this.axDiamondTouch1.Enabled = true;
            this.axDiamondTouch1.Location = new System.Drawing.Point(442, 110);
            this.axDiamondTouch1.Name = "axDiamondTouch1";
            this.axDiamondTouch1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDiamondTouch1.OcxState")));
            this.axDiamondTouch1.Size = new System.Drawing.Size(187, 91);
            this.axDiamondTouch1.TabIndex = 57;
            this.axDiamondTouch1.Visible = false;
            this.axDiamondTouch1.Touch += new AxDIAMONDTOUCHLib._DDiamondTouchEvents_TouchEventHandler(this.axDiamondTouch1_Touch);
            // 
            // axShockwaveFlash1
            // 
            this.axShockwaveFlash1.Enabled = true;
            this.axShockwaveFlash1.Location = new System.Drawing.Point(16, 44);
            this.axShockwaveFlash1.Name = "axShockwaveFlash1";
            this.axShockwaveFlash1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axShockwaveFlash1.OcxState")));
            this.axShockwaveFlash1.Size = new System.Drawing.Size(288, 277);
            this.axShockwaveFlash1.TabIndex = 58;
            this.axShockwaveFlash1.FlashCall += new AxShockwaveFlashObjects._IShockwaveFlashEvents_FlashCallEventHandler(this.axShockwaveFlash1_FlashCall);
            this.axShockwaveFlash1.FSCommand += new AxShockwaveFlashObjects._IShockwaveFlashEvents_FSCommandEventHandler(this.axShockwaveFlash1_FSCommand);
            // 
            // DTFlash
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.ClientSize = new System.Drawing.Size(503, 361);
            this.Controls.Add(this.axShockwaveFlash1);
            this.Controls.Add(this.axDiamondTouch1);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.btnHideBrowseButton);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.lblElapsedTime);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DTFlash";
            this.Text = "DTFlashEx";
            this.Load += new System.EventHandler(this.DTFlash_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.DTFlash_Closing);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DTFlash_KeyPress);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DTFlash_FormClosing);
            this.Resize += new System.EventHandler(this.DTFlash_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.axDiamondTouch1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axShockwaveFlash1)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() {
			Application.Run(new DTFlash());
		}

		private void DTFlash_Load(object sender, System.EventArgs e) {
			if (QueryPerformanceFrequency(out freq) == false) {
				// high-performance counter not supported
				MessageForm.Show("WARNING: High Performance Counter not supported");
				highPerfCounterValid = false;
			}
			if (boostProcessPriority) {
				Process proc = Process.GetCurrentProcess();
				proc.PriorityClass = ProcessPriorityClass.High;
			}
			freq2 = freq/1000;

			ReadConfigFile(false);

			StartTouchTable();
			if (diamondTouchStarted) {
				int cnt = axDiamondTouch1.getReceiverIdCount();
				m_lastTouchEventString = new string[cnt];
				m_lastTouchEventString = new string[axDiamondTouch1.getReceiverIdCount()];
			} else {
				m_lastTouchEventString = new string[5];
			}
			for (int i=0; i<m_lastTouchEventString.Length; i++) {
				m_lastTouchEventString[i] = "";
			}

			// init Flash
			axDiamondTouch1.EventSegmentEnable = m_EnableSegments;
			axDiamondTouch1.EventSignalEnable = m_EnableSignals;
			axDiamondTouch1.ScreenCoordinatesEnable = true;
			flashSwfPath = Application.StartupPath +"\\" + m_FlashFilename;
			if (m_Title == "")
				m_Title = m_FlashFilename;
			this.Text = m_Title;

			if (m_FullScreen) {
				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;
			} else if (m_Maximized) {
				this.WindowState = FormWindowState.Maximized;
			} else if (m_FlashMovieHeight > 0 && m_FlashMovieWidth > 0) {
				//axShockwaveFlash1.Size = New Size(m_FlashMovieWidth, m_FlashMovieHeight)
				if (m_ShowStatusBar) {
					this.ClientSize = new Size(m_FlashMovieWidth, m_FlashMovieHeight+ statusBar1.Height); // causes resize
				} else {
					this.ClientSize = new Size(m_FlashMovieWidth, m_FlashMovieHeight); // causes resize
				}
			}
			axShockwaveFlash1.Location = new Point(0, 0);
			if (m_ShowStatusBar) {
				axShockwaveFlash1.Size = new Size(this.ClientSize.Width, this.ClientSize.Height -statusBar1.Height);
			} else {
				axShockwaveFlash1.Size = this.ClientSize;
			}									
			if (m_PromptForUserRotations)
				axShockwaveFlash1.LoadMovie(0, Application.StartupPath +"\\rotationsPrompt.swf");
			else
				axShockwaveFlash1.LoadMovie(0, flashSwfPath);
			toucherRotationsStr = "";
			if (m_rotateUser.Length > 0)
				toucherRotationsStr += m_rotateUser[0];
			for (int i=1; i<m_rotateUser.Length; i++)
				toucherRotationsStr += "," + m_rotateUser[i];
			axShockwaveFlash1.SetVariable("dt.toucherRotationString",toucherRotationsStr);
			axShockwaveFlash1.SetVariable("dt.promptForUserRotations",toucherRotationsStr);
			axShockwaveFlash1.SetVariable("dt.eventSegmentEnable", m_EnableSegments.ToString().ToLower());
			axShockwaveFlash1.SetVariable("dt.eventSignalEnable", m_EnableSignals.ToString().ToLower());
			m_FlashMovieLoaded = true;
        }

		private void ReadConfigFile() {
			ReadConfigFile(false);
		}
		private void ReadConfigFile(bool verbose) {
			string summary = "Configuration elements loaded:" + "\r\n" +  "==============================";
			XmlDocument xmlDoc = new XmlDocument();
			string tag = "";

			try {
                xmlDoc.Load( "config.xml" );
			} catch (FileNotFoundException fnfex) {
				if (verbose) MessageForm.Show("Exception loading config file: " + fnfex.Message + "\r\n" + fnfex.ToString()+ "\r\n" + fnfex.StackTrace, "DTBoxes");
				return;
			} catch (Exception ex) {
				MessageForm.Show("Exception loading config file: " + ex.Message + "\r\n" +  ex.ToString()+ "\r\n" + ex.StackTrace, "DTBoxes");
				return;
			}

            XmlNodeList settings = xmlDoc.SelectNodes( "//DTFlash/*" );
            foreach( XmlNode setting in settings )
            {
                this.settings.Add( setting.Name, setting.InnerText );
            }

			try {
				int newInteger;
				bool newBoolean;
				string newString;

				try {
					tag = "FlashFilename";
					newString = xmlDoc.SelectSingleNode("//" + tag).InnerText.Trim();
					summary += "\r\n" + tag + "=" + newString;
					m_FlashFilename = newString;

                    string file = m_FlashFilename;
                    foreach( char c in Path.GetInvalidFileNameChars() )
                        file = file.Replace( c, '_' );
                    logFile = "C:\\DTFlash." + file + ".log";
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "Title";
					newString = xmlDoc.SelectSingleNode("//" + tag).InnerText.Trim();
					summary += "\r\n" + tag + "=" + newString;
					m_Title = newString;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "Maximized";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_Maximized = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "FullScreen";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_FullScreen = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "ShowStatusBar";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_ShowStatusBar = newBoolean;
					statusBar1.Visible = m_ShowStatusBar;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "FlashMovieWidth";
					newInteger = XmlConvert.ToInt32(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newInteger.ToString();
					m_FlashMovieWidth = newInteger;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "FlashMovieHeight";
					newInteger = XmlConvert.ToInt32(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newInteger.ToString();
					m_FlashMovieHeight = newInteger;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "EnableSegments";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_EnableSegments = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "EnableSignals";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_EnableSignals = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "IgnoreSubsequentIdenticalEvents";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_IgnoreSubsequentIdenticalEvents = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "ShowBrowseButton";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					btnBrowse.Visible = newBoolean;
					btnHideBrowseButton.Visible = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "ShowTouchDataInTitleBar";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_ShowTouchDataInTitleBar = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "PromptForUserRotations";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_PromptForUserRotations = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "ShowResizingDirectionArrows";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_ShowResizingDirectionArrows = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "ShowMovementDirectionArrows";
					newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newBoolean.ToString();
					m_ShowMovementDirectionArrows = newBoolean;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "RotateUser0";
					newInteger = XmlConvert.ToInt32(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newInteger.ToString();
					m_rotateUser[0] = newInteger;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "RotateUser1";
					newInteger = XmlConvert.ToInt32(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newInteger.ToString();
					m_rotateUser[1] = newInteger;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "RotateUser2";
					newInteger = XmlConvert.ToInt32(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newInteger.ToString();
					m_rotateUser[2] = newInteger;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

				try {
					tag = "RotateUser3";
					newInteger = XmlConvert.ToInt32(xmlDoc.SelectSingleNode("//" + tag).InnerText);
					summary += "\r\n" + tag + "=" + newInteger.ToString();
					m_rotateUser[3] = newInteger;
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}

                try
                {
                    tag = "UseAS3CallFunction";
                    newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
                    summary += "\r\n" + tag + "=" + newBoolean.ToString();                    
                    m_UseAS3CallFunction = newBoolean;
                }
                catch (Exception ex)
                {
                    if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message + "\r\n" + ex.StackTrace, "DTBoxes");
                }

                try
                {                    
                    tag = "UseAS2SetVariable";
                    newBoolean = XmlConvert.ToBoolean(xmlDoc.SelectSingleNode("//" + tag).InnerText);
                    summary += "\r\n" + tag + "=" + newBoolean.ToString();
                    m_UseAS2SetVariable = newBoolean;
                }
                catch (Exception ex)
                {
                    if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message + "\r\n" + ex.StackTrace, "DTBoxes");
                }

				try {
					tag = "ProcessPriority";
					newString = xmlDoc.SelectSingleNode("//" + tag).InnerText.Trim();
					summary += "\r\n" + tag + "=" + newString;
					switch (newString) {
						case "High": 
							Process proc1 = Process.GetCurrentProcess();
							proc1.PriorityClass = ProcessPriorityClass.High;
							break;
						case "AboveNormal": 
							Process proc2 = Process.GetCurrentProcess();
							proc2.PriorityClass = ProcessPriorityClass.AboveNormal;
							break;
						case "Normal": 
							Process proc3 = Process.GetCurrentProcess();
							proc3.PriorityClass = ProcessPriorityClass.Normal;
							break;
						case "BelowNormal": 
							Process proc4 = Process.GetCurrentProcess();
							proc4.PriorityClass = ProcessPriorityClass.BelowNormal;
							break;
						case "Low": 
							Process proc5 = Process.GetCurrentProcess();
							proc5.PriorityClass = ProcessPriorityClass.Idle;
							break;
					}
				} catch (Exception ex) {
					if (verbose) MessageForm.Show("Error reading config entry: " + tag + ". Exception: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
				}
			} catch (FormatException fex) {
				MessageForm.Show("Error reading config entry: " + tag + "\r\n" + fex.Message+ "\r\n" + fex.StackTrace, "DTBoxes");
			} catch (Exception ex) {
				MessageForm.Show("Error reading config file: " + ex.Message+ "\r\n" + ex.StackTrace, "DTBoxes");
			}
			if (verbose) MessageForm.Show(summary);
		}

		private void axDiamondTouch1_Touch(object sender, AxDIAMONDTOUCHLib._DDiamondTouchEvents_TouchEvent e) {
            if (m_UseAS2SetVariable) {
                SendDTEvent_UsingSetVariable(false, e);
            }
            if (m_UseAS3CallFunction) {
                SendDTEvent_UsingCallFunction(false, e);
            }
		}

        private void SendDTEvent_UsingSetVariable(bool includeGestureInfo, AxDIAMONDTOUCHLib._DDiamondTouchEvents_TouchEvent e) {
            try
            {
                System.Text.StringBuilder newXSegmentString = null;
                System.Text.StringBuilder newYSegmentString = null;
                e_timestamp = e.timestamp;
                if (!m_FlashMovieLoaded) return;
                Point pt = axShockwaveFlash1.PointToClient(new Point(e.x, e.y));
                Point ul_pt = axShockwaveFlash1.PointToClient(new Point(e.left, e.top));
                Point lr_pt = axShockwaveFlash1.PointToClient(new Point(e.right, e.bottom));
                string str = "";
                str += "receiver=" + e.receiverId.ToString();
                str += "&action=" + e.eventType.ToString();
                str += "&x=" + pt.X.ToString();
                str += "&y=" + pt.Y.ToString();
                str += "&ulx=" + ul_pt.X.ToString();
                str += "&uly=" + ul_pt.Y.ToString();
                str += "&lrx=" + lr_pt.X.ToString();
                str += "&lry=" + lr_pt.Y.ToString();
                //if (m_EnableSegments)
                //{
                    str += "&xSegmentCount=" + e.xSegmentCount;
                    str += "&ySegmentCount=" + e.ySegmentCount;
                    Point xsegStart_pt, xsegStop_pt, xsegMax_pt, ysegStart_pt, ysegStop_pt, ysegMax_pt;
                    short xsegStart, xsegStop, xsegMax, ysegStart, ysegStop, ysegMax;
                    newXSegmentString = new System.Text.StringBuilder(e.xSegmentString);
                    for (int i = 0; i < e.xSegmentCount; i++)
                    {
                        if (e.xSegmentString.Length == 0)
                        {
                            newXSegmentString.Append("abc");
                            newXSegmentString[i * 3 + 0] = (char)(short)(0);
                            newXSegmentString[i * 3 + 1] = (char)(short)(0);
                            newXSegmentString[i * 3 + 2] = (char)(short)(0);
                        }
                        else
                        {
                            xsegStart = (short)e.xSegmentString[i * 3 + 0];
                            xsegStop = (short)e.xSegmentString[i * 3 + 1];
                            xsegMax = (short)e.xSegmentString[i * 3 + 2];
                            xsegStart_pt = axShockwaveFlash1.PointToClient(new Point(xsegStart, 0));
                            xsegStop_pt = axShockwaveFlash1.PointToClient(new Point(xsegStop, 0));
                            xsegMax_pt = axShockwaveFlash1.PointToClient(new Point(xsegMax, 0));
                            // replace 0's with -1's so that string isn't prematurely terminated
                            if (xsegStart_pt.X == 0) xsegStart_pt.X = -1;
                            if (xsegStop_pt.X == 0) xsegStop_pt.X = -1;
                            if (xsegMax_pt.X == 0) xsegMax_pt.X = -1;
                            try
                            {
                                newXSegmentString[i * 3 + 0] = (char)(short)(xsegStart_pt.X);
                                newXSegmentString[i * 3 + 1] = (char)(short)(xsegStop_pt.X);
                                newXSegmentString[i * 3 + 2] = (char)(short)(xsegMax_pt.X);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Couldn't convert " + xsegStart + " or " + Convert.ToInt16(xsegStart_pt.X).ToString());
                                return;
                            }
                        }
                    }
                    newYSegmentString = new System.Text.StringBuilder(e.ySegmentString);
                    for (int i = 0; i < e.ySegmentCount; i++)
                    {
                        if (e.ySegmentString.Length == 0)
                        {
                            newYSegmentString.Append("abc");
                            newYSegmentString[i * 3 + 0] = (char)(short)(0);
                            newYSegmentString[i * 3 + 1] = (char)(short)(0);
                            newYSegmentString[i * 3 + 2] = (char)(short)(0);
                        }
                        else
                        {
                            ysegStart = (short)e.ySegmentString[i * 3 + 0];
                            ysegStop = (short)e.ySegmentString[i * 3 + 1];
                            ysegMax = (short)e.ySegmentString[i * 3 + 2];
                            ysegStart_pt = axShockwaveFlash1.PointToClient(new Point(0, ysegStart));
                            ysegStop_pt = axShockwaveFlash1.PointToClient(new Point(0, ysegStop));
                            ysegMax_pt = axShockwaveFlash1.PointToClient(new Point(0, ysegMax));
                            // replace 0's with -1's so that string isn't prematurely terminated
                            if (ysegStart_pt.Y == 0) ysegStart_pt.Y = -1;
                            if (ysegStop_pt.Y == 0) ysegStop_pt.Y = -1;
                            if (ysegMax_pt.Y == 0) ysegMax_pt.Y = -1;
                            try
                            {
                                newYSegmentString[i * 3 + 0] = (char)(short)(ysegStart_pt.Y);
                                newYSegmentString[i * 3 + 1] = (char)(short)(ysegStop_pt.Y);
                                newYSegmentString[i * 3 + 2] = (char)(short)(ysegMax_pt.Y);
                            }
                            catch (Exception ex2)
                            {
                                MessageBox.Show("Couldn't convert " + ysegStart.ToString() + " + or " + Convert.ToInt16(ysegStart_pt.Y).ToString());
                                return;
                            }
                        }
                    }
                //}
                str += "&valid=true"; // so Flash can distinguish valid input
                if (m_IgnoreSubsequentIdenticalEvents)
                {
                    if (e.receiverId > -1 && e.receiverId < axDiamondTouch1.getReceiverIdCount())
                    {
                        if (str.Equals(m_lastTouchEventString[e.receiverId]))
                        {
                            return;
                        }
                    }
                }
                str += "&timestamp=" + e.timestamp;
                // Segment and Signal strings contain binary data. They can't be URL-encoded because they might contain "&"
                if (m_EnableSegments)
                {
                    axShockwaveFlash1.SetVariable("dt.DtXSegmentString", newXSegmentString.ToString());//e.xSegmentString);
                    axShockwaveFlash1.SetVariable("dt.DtYSegmentString", newYSegmentString.ToString());//e.ySegmentString);
                }
                axShockwaveFlash1.SetVariable("dt.DtXSignalString", e.xSignalString);
                axShockwaveFlash1.SetVariable("dt.DtYSignalString", e.ySignalString);
                axShockwaveFlash1.SetVariable("dt.DtEvent", str);
                //updatePerformanceLabel(); // Do this in FromFlash_Notify handler after Flash kicks off GUI changes -- though 
                // GUI doesn't actually update til next frame (or event if updateAfterEvent)
                if (this.m_ShowTouchDataInTitleBar)
                {
                    this.Text = str;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("SendDTEvent exception: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
            }
        }


        private void SendDTEvent_UsingCallFunction(bool includeGestureInfo, AxDIAMONDTOUCHLib._DDiamondTouchEvents_TouchEvent e) {
			try {
				e_timestamp = e.timestamp;
				if (!m_FlashMovieLoaded) return;
				//Point pt = axShockwaveFlash1.PointToClient(new Point(e.x, e.y));
                Point pt = axShockwaveFlash1.PointToClient(new Point(e.left+(e.right-e.left)/2, e.top+(e.bottom-e.top)/2));
				Point ul_pt = axShockwaveFlash1.PointToClient(new Point(e.left, e.top));
				Point lr_pt = axShockwaveFlash1.PointToClient(new Point(e.right, e.bottom));
				string str = "";
				str += "receiver=" + e.receiverId.ToString();
				str += "&action=" + e.eventType.ToString();
				str += "&x=" + pt.X.ToString();
				str += "&y=" + pt.Y.ToString();
				str += "&ulx=" + ul_pt.X.ToString();
				str += "&uly=" + ul_pt.Y.ToString();
				str += "&lrx=" + lr_pt.X.ToString();
				str += "&lry=" + lr_pt.Y.ToString();
				str += "&xSegmentCount=" + e.xSegmentCount;
				str += "&ySegmentCount=" + e.ySegmentCount;
				Point xsegStart_pt, xsegStop_pt, xsegMax_pt, ysegStart_pt, ysegStop_pt, ysegMax_pt;
				short xsegStart, xsegStop, xsegMax, ysegStart, ysegStop, ysegMax;
				System.Text.StringBuilder newXSegmentString = new System.Text.StringBuilder(e.xSegmentString);
				for (int i=0; i< e.xSegmentCount; i++) {
					if (e.xSegmentString.Length == 0) {
						newXSegmentString.Append("abc");
						newXSegmentString[i*3+0] = (char)(short)(0);
						newXSegmentString[i*3+1] =  (char)(short)(0);
						newXSegmentString[i*3+2] =  (char)(short)(0);
					} else {
						xsegStart = (short)e.xSegmentString[i*3 + 0];
						xsegStop = (short)e.xSegmentString[i*3 + 1];
						xsegMax = (short)e.xSegmentString[i*3 + 2];
						xsegStart_pt = axShockwaveFlash1.PointToClient(new Point(xsegStart, 0));
						xsegStop_pt = axShockwaveFlash1.PointToClient(new Point(xsegStop, 0));
						xsegMax_pt = axShockwaveFlash1.PointToClient(new Point(xsegMax, 0));
						// replace 0's with -1's so that string isn't prematurely terminated
						if (xsegStart_pt.X == 0) xsegStart_pt.X = -1;
						if (xsegStop_pt.X == 0) xsegStop_pt.X = -1;
						if (xsegMax_pt.X == 0) xsegMax_pt.X = -1;
						try {						
							newXSegmentString[i*3+0] = (char)(short)(xsegStart_pt.X);
							newXSegmentString[i*3+1] =  (char)(short)(xsegStop_pt.X);
							newXSegmentString[i*3+2] =  (char)(short)(xsegMax_pt.X);
						} catch {
							MessageForm.Show("Couldn't convert " + xsegStart + " or " + Convert.ToInt16(xsegStart_pt.X).ToString());
							return;
						}
					}
				}
				System.Text.StringBuilder newYSegmentString = new System.Text.StringBuilder(e.ySegmentString);
				for (int i=0; i< e.ySegmentCount; i++) {
					if (e.ySegmentString.Length == 0) {
						newYSegmentString.Append("abc");
						newYSegmentString[i*3+0] = (char)(short)(0);
						newYSegmentString[i*3+1] =  (char)(short)(0);
						newYSegmentString[i*3+2] =  (char)(short)(0);
					} else {
						ysegStart = (short)e.ySegmentString[i*3 + 0];
						ysegStop = (short)e.ySegmentString[i*3 + 1];
						ysegMax = (short)e.ySegmentString[i*3 + 2];
						ysegStart_pt = axShockwaveFlash1.PointToClient(new Point(0, ysegStart));
						ysegStop_pt = axShockwaveFlash1.PointToClient(new Point(0, ysegStop));
						ysegMax_pt = axShockwaveFlash1.PointToClient(new Point(0, ysegMax));
						// replace 0's with -1's so that string isn't prematurely terminated
						if (ysegStart_pt.Y == 0) ysegStart_pt.Y = -1;
						if (ysegStop_pt.Y == 0) ysegStop_pt.Y = -1;
						if (ysegMax_pt.Y == 0) ysegMax_pt.Y = -1;
						try {
							newYSegmentString[i*3+0] = (char)(short)(ysegStart_pt.Y);
							newYSegmentString[i*3+1] = (char)(short)(ysegStop_pt.Y);
							newYSegmentString[i*3+2] = (char)(short)(ysegMax_pt.Y);
						} catch {
							MessageForm.Show("Couldn't convert " + ysegStart.ToString() +" + or " + Convert.ToInt16(ysegStart_pt.Y).ToString());
							return;
						}
					}
				}
				str += "&valid=true"; // so Flash can distinguish valid input
				if (m_IgnoreSubsequentIdenticalEvents) {
					if (e.receiverId > -1 && e.receiverId < axDiamondTouch1.getReceiverIdCount()) {
						if (str.Equals(m_lastTouchEventString[e.receiverId])) {
							return;
						}
					}
				}
				str += "&timestamp=" + e.timestamp;


				// Segment and Signal strings contain binary data. They can't be URL-encoded because they might contain "&"

                //string encodedXSegment = Convert.ToBase64String(Encoding.Unicode.GetBytes(newXSegmentString.ToString()));
                //string encodedYSegment = Convert.ToBase64String(Encoding.Unicode.GetBytes(newYSegmentString.ToString()));
                //string encodedXSignal  = Convert.ToBase64String(Encoding.Unicode.GetBytes(e.xSignalString));
                //string encodedYSignal = Convert.ToBase64String(Encoding.Unicode.GetBytes(e.ySignalString));
                //string signalSegmentCall =
                //    "<invoke name=\"setSignalSegments\" returntype=\"xml\">\r\n" +
                //    "    <arguments>\r\n" +
                //    "        <string><![CDATA[" + encodedXSegment + "]]></string>\r\n" +
                //    "        <string><![CDATA[" + encodedYSegment + "]]></string>\r\n" +
                //    "        <string><![CDATA[" + encodedXSignal + "]]></string>\r\n" +
                //    "        <string><![CDATA[" + encodedYSignal + "]]></string>\r\n" +
                //    "    </arguments>\r\n" +
                //    "</invoke>";
                //MessageForm.Show( signalSegmentCall );
                //File.AppendAllText(logFile, signalSegmentCall + "\r\n********************************************\r\n");
                //axShockwaveFlash1.CallFunction( signalSegmentCall );

                string newDTEventCall =
                    "<invoke name=\"onDTData\" returntype=\"xml\">" +
                        "<arguments><string><![CDATA[" + str + "]]></string></arguments>" +
                    "</invoke>";
                if (this.m_ShowTouchDataInTitleBar) {
                    //this.Text = newDTEventCall;
                    this.Text = "DT x,y=" + e.x + "," + e.y + " Flash x,y=" + pt.X + "," + pt.Y;
                }
                axShockwaveFlash1.CallFunction( newDTEventCall );

				//updatePerformanceLabel(); // Do this in FromFlash_Notify handler after Flash kicks off GUI changes -- though 
				// GUI doesn't actually update til next frame (or event if updateAfterEvent)
			} catch (Exception ex) {
				MessageForm.Show("SendDTEvent_UsingCallFunction exception: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
			}
		}

		private void DTFlash_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			StopTouchTable();
		}

		private void DTFlash_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e) {
			//Pressing the ESCAPE key will exit the program
			// BUT NOT IF FLASH HAS THE KEYBOARD FOCUS!
			if (e.KeyChar == (char)Keys.Escape) {
				this.Close();
			}
		}

		private void axShockwaveFlash1_FSCommand(object sender, AxShockwaveFlashObjects._IShockwaveFlashEvents_FSCommandEvent e) {
			if (e.command == "STOP") {
				tmrStopAndExit.Enabled = true;
			}
		}

		private void tmrStopAndExit_Tick(object sender, System.EventArgs e) {
			tmrStopAndExit.Enabled = false;
			this.Close();
		}

		private void DTFlash_Resize(object sender, System.EventArgs e) {
			if (!m_FlashMovieLoaded) return;
			max_diff = 0;
			if (m_ShowStatusBar) {
				axShockwaveFlash1.Size = new Size(this.ClientSize.Width, this.ClientSize.Height -statusBar1.Height);
			} else {
				axShockwaveFlash1.Size = this.ClientSize;
			}
            if (m_UseAS2SetVariable) {
                axShockwaveFlash1.SetVariable("dt.DtEvent", "resize=true&valid=true");
            }
            if (m_UseAS3CallFunction){
                string str = "resize=true&valid=true";
                string newDTEventCall =
                    "<invoke name=\"onDTData\" returntype=\"xml\">" +
                        "<arguments><string><![CDATA[" + str + "]]></string></arguments>" +
                    "</invoke>";
                axShockwaveFlash1.CallFunction(newDTEventCall);

            }
			
		}

		#region timer
		[DllImport("Kernel32.dll")]
		private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

		[DllImport("Kernel32.dll")]
		private static extern bool QueryPerformanceFrequency(out long lpFrequency);

		private long TouchEventReceivedTime;
		private long freq;
		private bool highPerfCounterValid = true;
		private long freq2; //freq2 = freq/1000;
		private bool showPerformanceInfo = false;
		private bool boostProcessPriority = false;
		private long e_timestamp;
		private long max_diff = 0;
		private void updatePerformanceLabel() {
			if (showPerformanceInfo) {
				if (highPerfCounterValid) {
					QueryPerformanceCounter(out TouchEventReceivedTime);
					//long freq2 = freq/1000;
					TouchEventReceivedTime = TouchEventReceivedTime / freq2;
					if ((long)(TouchEventReceivedTime - e_timestamp) > max_diff)
						max_diff = (long)(TouchEventReceivedTime - e_timestamp);
					lblElapsedTime.Text= 
						"e.timestamp=                  " + String.Format("{0:X8}", (e_timestamp)) +
						"\nTouchEventReceivedTime=" + String.Format("{0:X8}", (long)TouchEventReceivedTime) +					
						"\nfreq=" + freq.ToString() +
						"\nmax_diff=" + max_diff.ToString() +
						"\ndiff = " + String.Format("{0:G}", (long)(TouchEventReceivedTime - e_timestamp));//Convert.ToString((double)(TouchEventReceivedTime - e.timestamp));
				}
			}
		}

		#endregion timer

		private void axShockwaveFlash1_Enter(object sender, System.EventArgs e) {
		
		}

		private void axShockwaveFlash1_FlashCall(object sender, AxShockwaveFlashObjects._IShockwaveFlashEvents_FlashCallEvent e) {
			//MessageForm.Show("axShockwaveFlash1_FlashCall: " + e.request);
			// incoming e.request is XML:
			//	<invoke name="Flash_SurfaceMove" returntype="xml">
			//		<arguments>
			//			<string>7120ca0e-5e03-44bf-9c4e-178745b6e163</string>
			//			<number>460.81</number>
			//			<number>131.12</number>
			//		</arguments>
			//	</invoke>
			// Now C# should invoke the method...

			try {
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(e.request);
				XmlNode docElement = doc.DocumentElement;
				//XmlNodeList nl = docElement.Attributes(
				string str = "";
				//foreach (XmlNode n in  docElement.ChildNodes[0].ChildNodes) {
				//str += n.Name;
				string invokedMethodName = "";
				foreach (XmlAttribute attr in docElement.Attributes) {
					if (attr.Name.Equals("name")) {
						invokedMethodName = attr.Value;
						break;
					}
				}
				XmlNode n;
				string surfaceGuid;
				switch (invokedMethodName) {
					case "FromFlash_Notify":
						n = docElement.SelectSingleNode("//invoke/arguments/string[position() = 1]/text()");
						surfaceGuid = n.InnerText;
						n = docElement.SelectSingleNode("//invoke/arguments/number[position() = 1]/text()");
						int surfaceLeft = (int) Math.Round(Decimal.Parse(n.InnerText));
						n = docElement.SelectSingleNode("//invoke/arguments/number[position() = 2]/text()");
						int surfaceTop = (int) Math.Round(Decimal.Parse(n.InnerText));
						//MessageForm.Show("GUID=" + surfaceGuid+" left=" + surfaceLeft.ToString() + " top=" + surfaceTop.ToString());
						updatePerformanceLabel();
						break;
					case "FlashLoadedAndListening": //DTFlash calls this, but rotationsPrompt.swf doesn't
						// Now we can pass preferred rotations etc (anything from the C# config file)
						//
						axShockwaveFlash1.SetVariable("dt.xAntennaCount", axDiamondTouch1.getXAntennaCount().ToString());
						axShockwaveFlash1.SetVariable("dt.yAntennaCount", axDiamondTouch1.getYAntennaCount().ToString());
						axShockwaveFlash1.SetVariable("dt.antennaPitchUm", axDiamondTouch1.getAntennaPitchUm().ToString());
						//						
						axShockwaveFlash1.SetVariable("_root.ShowResizingDirectionArrows", m_ShowResizingDirectionArrows.ToString().ToLower());
						axShockwaveFlash1.SetVariable("_root.ShowMovementDirectionArrows", m_ShowMovementDirectionArrows.ToString().ToLower());						
						toucherRotationsStr = "";
						if (m_rotateUser.Length > 0)
							toucherRotationsStr += m_rotateUser[0];
						for (int i=1; i<m_rotateUser.Length; i++)
							toucherRotationsStr += "," + m_rotateUser[i];
						axShockwaveFlash1.SetVariable("dt.toucherRotationString",toucherRotationsStr);
						axShockwaveFlash1.SetVariable("dt.promptForUserRotations","false");//C# already loaded rotationsPrompt.swf
						break;
					case "Flash_RotationsPromptComplete":
						axShockwaveFlash1.SetVariable("nextMovie", flashSwfPath);
						n = docElement.SelectSingleNode("//invoke/arguments/string[position() = 1]/text()");
						string rotations = n.InnerText;
						//MessageForm.Show("got Flash_RotationsPromptComplete signal from Flash. rotations=" +rotations+ "\n" +
						//	flashSwfPath);	
						string[] rotvals = rotations.Split();
						for (int i=0; i< rotvals.Length; i++) {
							m_rotateUser[i] = Convert.ToInt32(rotvals[i]);
						}
						//string s = "";
						//for (int j=0; j<rotvals.Length; j++) 
						//	s += rotvals[j].ToString() + " ";
						//MessageForm.Show("got Flash_RotationsPromptComplete signal from Flash. rotations=" +s+ "\n" +
						//	flashSwfPath);	
						//
						//Flash will now do a _root.LoadMovie(nextMovie) and blow away state. 
						//Pass new movie the new rotations and all in "FlashLoadedAndListening"
						break;
					case "FlashWantsToQuit":
						// Rather than exit right a way, start a timer that handles the exiting after a brief delay. 
						// This shuts down more cleanly because the Flash command that got us here can nicely return, first.
						tmrStopAndExit.Enabled = true;
						break;
                    default:
						break;
				}
				str += "\r\n";
				//}
				//MessageForm.Show(str);
			} catch (Exception ex) {
				MessageForm.Show("axShockwaveFlash1_FlashCall exception: " + ex.Message + "\r\n" + ex.StackTrace);
			}
			axShockwaveFlash1.SetReturnValue("<string>My return string from C# to Flash</string");
		}

		private void StartTouchTable() {
			int res;
			String str;

			res = axDiamondTouch1.Start();
			if (res == 0) {
				diamondTouchStarted = true;
			} else {
				diamondTouchStarted = false;
				switch(res) {
					case 1:
						str = "Warning starting DiamondTouch: already started"; 
						diamondTouchStarted = true;
						break;
					case 2:
						str = "Error starting DiamondTouch: no device (couldn't find a USB DiamondTouch device)"; break;
					case 3:
						str = "Error starting DiamondTouch: open failed"; break;
					case 4:
						str = "Error starting DiamondTouch: serial device (not supported)"; break;
					case 5:
						str = "Error starting DiamondTouch: thread start failed (couldn't start up a thread for some reason)"; break;
					default:
						str = "Error starting DiamondTouch: unknown error"; break;
				}
				//MessageForm.Show( str, "DiamondTouch Error", MessageBoxButtons.OK);
                MessageForm.Show( str );
			}
			System.Threading.Thread.Sleep(100); // ActiveX control created a new thread to start the device
		}

		private void StopTouchTable() {
			if ( diamondTouchStarted) {
				axDiamondTouch1.Stop();
				diamondTouchStarted = false;
			}
		}

		private void btnBrowse_Click(object sender, System.EventArgs e) {
			openFileDialog1.InitialDirectory = Application.StartupPath;
			if (openFileDialog1.ShowDialog() == DialogResult.OK) {
				flashSwfPath = openFileDialog1.FileName;
				m_Title = flashSwfPath;
				this.Text = m_Title;
				axShockwaveFlash1.LoadMovie(0, flashSwfPath);
				m_FlashMovieLoaded = true;
			}
		}

		private void btnHideBrowseButton_Click(object sender, System.EventArgs e) {
			btnBrowse.Visible = false;
			btnHideBrowseButton.Visible = false;
		}

        private void DTFlash_FormClosing( object sender, FormClosingEventArgs e )
        {
        }

	}
}
