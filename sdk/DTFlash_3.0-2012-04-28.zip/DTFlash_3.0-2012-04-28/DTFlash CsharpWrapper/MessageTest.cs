using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DTFlash
{
    public partial class MessageTest : Form
    {
        public MessageTest()
        {
            InitializeComponent();
        }

        void RunApp()
        {
            MessageForm.ShowMessage( "This is a longer message (shown for 2 seconds)", 2000 );
            MessageForm.ShowMessage( "Second Message (shown for 4.5 seconds)", 4500 );
            MessageForm.ShowMessage( "Third Message (shown for 3 seconds)", 3000 );
            MessageForm.ShowMessage( "Fourth Message (shown for 4 seconds)", 4000 );
            MessageForm.ShowMessage( "Fifth Message (shown for 3 seconds)", 3000 );
            MessageForm.ShowMessage( "Sixth Message (shown for 2 seconds)", 2000 );
            MessageForm.ShowMessage( "Seventh Message (shown for 7 seconds)", 7000 );
        }

        private void button1_Click( object sender, EventArgs e )
        {
            RunApp();
        }
    }
}