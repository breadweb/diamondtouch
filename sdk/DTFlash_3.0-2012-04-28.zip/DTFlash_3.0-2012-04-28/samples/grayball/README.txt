
DTFlash uses a custom ActiveX control. Run register_DiamondTouchEx_activeX_control.bat to register it.

To create new .swf files, you'll need the "com" directory to be in the same directory as your Flash .fla file. (Or point to it via some path.)

The C# DTFlash.exe utility can be used to pass touch events from the DT activeX control to a Flash .swf file. This is generally more simple than giving your browser permissions to run the DiamondTouch ActiveX control. To use DTFlash.exe, just specify the name of your .swf file in the config.xml file that is in the same directory as DTFlash.exe. See the config.xml file for other options.

See "DTFlash Application Development.html" for detailed instructions on creating applications.

